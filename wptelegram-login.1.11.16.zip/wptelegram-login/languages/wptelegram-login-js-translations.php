<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: ../../packages/js/services/api-fetch/index.ts:36
	__( 'Something went wrong', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/api-fetch/index.ts:38
	__( 'Could not connect', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/api-fetch/index.ts:41
	__( 'Error:', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/telegram/telegram-utils.ts:122
	__( 'A message will be sent to the Channel/Group/Chat. You can modify the text below', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/telegram/telegram-utils.ts:125
	__( 'This is a test message', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/telegram/telegram-utils.ts:129
	__( 'Message is empty', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/telegram/telegram-utils.ts:148
	__( 'Success', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/use-display-feedback.ts:60
	__( 'Lets fix these errors first.', 'wptelegram-login' ),

	// Reference: ../../packages/js/services/use-submit-form.ts:64
	__( 'Changes saved successfully.', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/components/instructions.tsx:17
	__( 'INSTRUCTIONS!', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/components/plugin-info/plugin-info-card.tsx:59
	/* translators: %s: plugin name */
	__( 'Do you like %s?', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/components/plugin-info/plugin-info-card.tsx:69
	__( 'Write a review', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/components/plugin-info/plugin-info-card.tsx:85
	__( 'Need help?', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/components/widget-info/widget-info-card.tsx:24
	__( 'Widget Info', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/components/wptg-social-icons.tsx:42
	/* translators: %s: social handle */
	__( 'Follow %s', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/components/wptg-social-icons.tsx:57
	/* translators: %s: channel name */
	__( 'Join %s', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/form/bot-token-field.tsx:45
	__( 'Please read the instructions above.', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/form/submit/submit-button.tsx:9
	// Reference: js/settings/ui/Instructions.tsx:106
	__( 'Save Changes', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/form/test-result/render-test-result.tsx:39
	__( 'Test Result:', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/form/use-bot-token-test.tsx:66
	__( 'Please wait…', 'wptelegram-login' ),

	// Reference: ../../packages/js/shared-ui/form/use-bot-token-test.tsx:67
	// Reference: js/settings/ui/TelegramOptions.tsx:38
	__( 'Test Token', 'wptelegram-login' ),

	// Reference: ../../packages/js/utilities/fields.ts:35
	// Reference: js/settings/services/fields.ts:70
	__( 'Invalid %s', 'wptelegram-login' ),

	// Reference: ../../packages/js/utilities/fields.ts:39
	// Reference: js/settings/services/fields.ts:57
	__( '%s required.', 'wptelegram-login' ),

	// Reference: ../../packages/js/utilities/fields.ts:42
	__( 'Changes could not be saved.', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:103
	// Reference: js/settings/services/fields.ts:25
	__( 'Language', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:111
	// Reference: js/settings/services/fields.ts:24
	__( 'Show if user is', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:20
	// Reference: js/settings/ui/ButtonOptions.tsx:14
	__( 'Large', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:21
	// Reference: js/settings/ui/ButtonOptions.tsx:15
	__( 'Medium', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:22
	// Reference: js/settings/ui/ButtonOptions.tsx:16
	__( 'Small', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:78
	__( 'Button Settings', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:81
	// Reference: js/settings/services/fields.ts:16
	__( 'Button Style', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:87
	// Reference: js/settings/services/fields.ts:27
	__( 'Show User Photo', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/Edit.tsx:93
	// Reference: js/settings/services/fields.ts:17
	__( 'Corner Radius', 'wptelegram-login' ),

	// Reference: js/blocks/telegram-login/index.tsx:21
	// Reference: js/settings/ui/WidgetInfoCard.tsx:32
	__( 'WP Telegram Login', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:13
	__( 'Avatar URL Meta Key', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:14
	__( 'Bot Token', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:15
	__( 'Bot Username', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:18
	__( 'Error message text', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:19
	__( 'Disable Sign up', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:20
	__( 'Hide on default login', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:21
	__( 'Random Email', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:22
	__( 'Redirect to', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:23
	// Reference: js/settings/ui/LoginOptions.tsx:18
	__( 'Custom URL', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:26
	__( 'Show error message', 'wptelegram-login' ),

	// Reference: js/settings/services/fields.ts:28
	__( 'User Role', 'wptelegram-login' ),

	// Reference: js/settings/ui/ButtonOptions.tsx:108
	__( 'Who can see the login button.', 'wptelegram-login' ),

	// Reference: js/settings/ui/ButtonOptions.tsx:128
	__( 'Hide the button on default WordPress login/register page.', 'wptelegram-login' ),

	// Reference: js/settings/ui/ButtonOptions.tsx:25
	__( 'Button Options', 'wptelegram-login' ),

	// Reference: js/settings/ui/ButtonOptions.tsx:51
	__( 'Display Telegram user profile photo beside button.', 'wptelegram-login' ),

	// Reference: js/settings/ui/ButtonOptions.tsx:72
	// Reference: js/settings/ui/ErrorMessageOptions.tsx:48
	__( 'Leave empty for default.', 'wptelegram-login' ),

	// Reference: js/settings/ui/ButtonOptions.tsx:87
	__( 'Language for the login button.', 'wptelegram-login' ),

	// Reference: js/settings/ui/ErrorMessageOptions.tsx:18
	__( 'Error Message', 'wptelegram-login' ),

	// Reference: js/settings/ui/ErrorMessageOptions.tsx:26
	__( 'Display an error message if Telegram is blocked by user\'s ISP.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:102
	__( 'Test your bot token below and fill in the bot username if not filled automatically.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:106
	__( 'Hit %s below', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:107
	__( 'That\'s it. You are ready to rock :)', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:17
	__( 'Note:', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:19
	__( 'You can use the same bot for all the WP Telegram plugins.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:28
	/* translators: 1 command name, 2 bot name */
	__( 'Create a Bot by sending %1$s command to %2$s.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:49
	/* translators: %s bot name */
	__( 'After completing the steps %s will provide you the Bot Token.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:55
	__( 'Copy the token and paste into the Bot Token field below.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:59
	/* translators: %s application name */
	__( 'For ease, use %s', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:65
	__( 'Telegram Desktop', 'wptelegram-login' ),

	// Reference: js/settings/ui/Instructions.tsx:75
	/* translators: 1 command name, 2 bot name, 3 site url */
	__( 'Send %1$s command to %2$s, select your bot and then send %3$s', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:123
	__( 'The user meta key to be used to save Telegram photo URL.', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:145
	__( 'If enabled, a random email address will be generated for new user accounts.', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:147
	__( 'Useful when you want the users to be able to receive private notifications.', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:15
	__( 'Default', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:16
	__( 'Homepage', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:17
	__( 'Current page', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:38
	__( 'Login Options', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:46
	__( 'If enabled, only the existing users who have connected their Telegram will be able to login.', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:67
	__( 'The default role to assign for the new users.', 'wptelegram-login' ),

	// Reference: js/settings/ui/LoginOptions.tsx:88
	__( 'Redirect location after login.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Sidebar.tsx:20
	__( 'Let the users login to your WordPress website with their Telegram and make it simple for them to get connected and let them receive their email notifications on Telegram.', 'wptelegram-login' ),

	// Reference: js/settings/ui/Sidebar.tsx:23
	__( 'Join our public chat on Telegram', 'wptelegram-login' ),

	// Reference: js/settings/ui/Sidebar.tsx:28
	__( 'Support', 'wptelegram-login' ),

	// Reference: js/settings/ui/TelegramOptions.tsx:21
	__( 'Telegram Options', 'wptelegram-login' ),

	// Reference: js/settings/ui/TelegramOptions.tsx:37
	__( 'Use %s above to set automatically.', 'wptelegram-login' ),

	// Reference: js/settings/ui/WidgetInfoCard.tsx:19
	/* translators: 1, 2 Menu names */
	__( 'Goto %1$s and click/drag %2$s and place it where you want it to be.', 'wptelegram-login' ),

	// Reference: js/settings/ui/WidgetInfoCard.tsx:28
	__( 'Appearance', 'wptelegram-login' ),

	// Reference: js/settings/ui/WidgetInfoCard.tsx:29
	__( 'Widgets', 'wptelegram-login' ),

	// Reference: js/settings/ui/WidgetInfoCard.tsx:37
	__( 'Alternately, you can use the below shortcode or the block available in block editor.', 'wptelegram-login' ),

	// Reference: js/settings/ui/WidgetInfoCard.tsx:41
	__( 'Inside page or post content:', 'wptelegram-login' ),

	// Reference: js/settings/ui/WidgetInfoCard.tsx:49
	__( 'Inside the theme templates', 'wptelegram-login' ),

	// Reference: js/settings/ui/WidgetInfoCard.tsx:57
	__( 'or', 'wptelegram-login' )
);
/* THIS IS THE END OF THE GENERATED FILE */
