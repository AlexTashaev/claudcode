<?php
/**
 * Silence is golden.
 *
 */